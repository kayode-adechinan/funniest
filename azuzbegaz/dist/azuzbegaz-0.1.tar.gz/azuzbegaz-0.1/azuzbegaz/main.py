def az():
    return ("azuz begaz")
