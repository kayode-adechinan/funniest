from setuptools import setup

setup(name='azuzbegaz',
      version='0.1',
      description='azuzbegaz',
      author='Kayode Adechinan',
      author_email='kayode.adechinan@example.com',
      license='MIT',
      packages=['azuzbegaz'],
      zip_safe=False)
