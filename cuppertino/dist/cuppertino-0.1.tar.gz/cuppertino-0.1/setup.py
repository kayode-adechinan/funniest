from setuptools import setup

setup(name='cuppertino',
      version='0.1',
      description='Live and die in Cuppertino',
      url='https://github.com/kayode-adechinan/funniest',
      author='Kayode Adechinan',
      author_email='kayode.adechinan@example.com',
      license='MIT',
      packages=['cuppertino'],
      zip_safe=False)
