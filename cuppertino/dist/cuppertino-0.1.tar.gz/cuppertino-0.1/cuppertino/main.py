def hello_cuppertino():
    return ("i love cuppertino")
